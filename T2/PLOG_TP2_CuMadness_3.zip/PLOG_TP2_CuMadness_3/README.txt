3MIEIC02
CuMadness_3

up201404022 - Paulo S�rgio Silva Babo 
up201404380 - Nuno Filipe Sousa e Silva
----------------------------------------------------------------------------------------------------------------------

Como utilizar:

- com o SICStus, fazer consult de "main.pl"
- obter as solu��es executando na consola "solveCube(X,N)." onde N � o tamanho da aresta do cubo a resolver (N > 0).

ir� aparecer a representa��o de uma solu��o e ser� pedida a interven��o do utilizador.

- para visualizar outra solu��o, executar na consola "n."
- para terminar, executar na consola "y."